public class DeluxeBurger extends Hamburger{
    private double basePrice = 19.10;

    public DeluxeBurger(String name, String meat, double price, String breadRollType) {
        super(name, meat, price, breadRollType);
        this.basePrice = basePrice;
    }

    @Override
    public void addHamburgerAddition1(String addition1Name, double price) {
        //super.addHamburgerAddition1(addition1Name, price);
        System.out.println("No additional Items can be added to a deluxe burger");
    }

    @Override
    public void addHamburgerAddition2(String addition2Name, double price) {
       // super.addHamburgerAddition2(addition2Name, price);
        System.out.println("No additional Items can be added to a deluxe burger");
    }

    @Override
    public void addHamburgerAddition3(String addition3Name, double price) {
        //super.addHamburgerAddition3(addition3Name, price);
        System.out.println("No additional Items can be added to a deluxe burger");
    }

    @Override
    public void addHamburgerAddition4(String addition4Name, double price) {
        //super.addHamburgerAddition4(addition4Name, price);
        System.out.println("No additional Items can be added to a deluxe burger");
    }
}
