public class Hamburger {
    private String name;
    private String meat;
    private double price;
    private String breadRollType;
    private String addition1Name;
    private double addition1Price;
    private String addition2Name;
    private double addition2Price;
    private String addition3Name;
    private double addition3Price;
    private String addition4Name;
    private double addition4Price;

    public Hamburger(String name, String meat, double price, String breadRollType) {
        this.name = name;
        this.meat = meat;
        this.price = price;
        this.breadRollType = breadRollType;
        /**this.addition1Name = addition1Name;
        this.addition1Price = addition1Price;
        this.addition2Name = addition2Name;
        this.addition2Price = addition2Price;
        this.addition3Name = addition3Name;
        this.addition3Price = addition3Price;
        this.addition4Name = addition4Name;
        this.addition4Price = addition4Price;**/

    }

    public void addHamburgerAddition1(String addition1Name,double price){
           this.addition1Name = addition1Name;
           this.addition1Price = price;
    }
    public void addHamburgerAddition2(String addition2Name,double price){
        this.addition2Name = addition2Name;
        this.addition2Price = price;
    }
    public void addHamburgerAddition3(String addition3Name,double price){
        this.addition3Name = addition3Name;
        this.addition3Price = price;
    }
    public void addHamburgerAddition4(String addition4Name,double price){
        this.addition4Name = addition4Name;
        this.addition4Price = price;
    }

    public double itemizehamburger(){
        double totalPrice = this.addition1Price + this.addition2Price +
                this.addition3Price + this.addition4Price + this.price;
        System.out.println("total price is " + totalPrice);
             return totalPrice;
    }
}
